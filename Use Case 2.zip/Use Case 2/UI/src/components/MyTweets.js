import React, { useEffect, useState } from "react"
import Axios from "axios";
import personLogo from "../components/images/person.jpg";
import deleteLogo from "../components/images/delete.png";
import { getUser, removeButtons,timeFormating } from "../Utils/Common";

const MyTweets = () => {

    const [userData, setuserData] = useState(null);
    removeButtons();
    document.title = "MyTweets";

    const getAllUsers = () => {
        let getuserUrl = `http://localhost:8090/api/v1.0/tweets/UsersTweet/?email=${getUser()}`;

        Axios.get(getuserUrl)
            // eslint-disable-next-line
            .then((respons) => {
                console.log(respons.data);
                setuserData(respons.data);
            });
    }

    const handleDeleteTweet = (e) => {
        let deleteUrl = `http://localhost:8090/api/v1.0/tweets/delete/?tweetId=${e.target.id}`;
        Axios.delete(deleteUrl)
            // eslint-disable-next-line
            .then((respons) => {
                getAllUsers();
            });
    }

    

    useEffect(() => {
        getAllUsers();
    }, []);

    return (
        <div style={{ "display": "table-cell" }}>
            <h1 style={{ "position": "relative", "margin-bottom": "20px" }}>
                My Tweets:
            </h1>
            {userData && userData.map((item, index) => (
                (item.tweetDesc !== "") && (
                    <div
                        key={index}>
                        <div
                            className="usertweet-wrapper">
                            <img
                                src={personLogo}
                                className="personImgUser">
                            </img>
                            <label
                                style={{ "position": "relative"}}>
                                Posted on {timeFormating(new Date(item.date))} ago
                            </label>
                            <label>
                                <img
                                    src={deleteLogo}
                                    id={item.tweetId}
                                    onClick={handleDeleteTweet}
                                    className="deleteLogo">
                                </img>
                            </label>
                            <span
                                style={{ "fontSize": "20px", "color": "brown", "display": "block", "font-weight": "bold", "paddingTop": "15px" }}>
                                {item.tweetDesc}
                            </span>
                        </div>
                        <br />
                    </div>
                )
            ))}
        </div>
    )
}


export default MyTweets;

import React, { useEffect, useState } from "react"
import Axios from "axios";
import personLogo from "../components/images/person.jpg";
import { removeButtons } from "../Utils/Common";

const ShowAllUsers = () => {

    const [userData, setuserData] = useState(null);
    removeButtons();
    document.title = "ShowAllUsers";

    const getAllUsers = () => {
        let getuserUrl = "http://localhost:8090/api/v1.0/tweets/getallUsers";

        Axios.get(getuserUrl)
            // eslint-disable-next-line
            .then((respons) => {
                console.log(respons.data);
                setuserData(respons.data);
            });
    }

    useEffect(() => {
        getAllUsers();
    }, []);

    return (
        <div>
            <h1 style={{ "color": "aliceblue", "left": "12%", "position": "relative" }}>
                All Users...
            </h1>
            {userData && userData.map((item, index) => (
                <div key={index}>
                    <div className="allusers-wrapper">
                        <img src={personLogo} className="personImgUser"></img>
                        <label style={{ "fontSize": "32px", "color": "aliceblue","position": "relative"}}>
                            {item.email}
                        </label>
                    </div>
                    <br />
                </div>
            ))}
        </div>
    )
}


export default ShowAllUsers;

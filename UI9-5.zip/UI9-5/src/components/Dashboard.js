import React, { useEffect, useState } from 'react';
import "./styles/LoginStyle.css";
import personLogo from "../components/images/person.jpg";
import Axios from "axios";
import { getUser, removeButtons, timeFormating } from '../Utils/Common';
import likeLogo from "../components/images/like2.png";
import like from "../components/images/like.png";
import { color } from 'd3';

const Dashboard = (props) => {
    const [userData, setuserData] = useState(null);
    removeButtons();

    document.title = "Tweets";

    const getTweets = () => {
        let getTweetUrl = "http://localhost:8090/api/v1.0/tweets/gettweets";
        
        Axios.get(getTweetUrl)
            // eslint-disable-next-line
            .then((respons) => {
                console.log(respons.data);
                setuserData(respons.data);
            });
    }

    const handleDeleteTweet = (e) => {
        let deleteUrl = `http://localhost:8090/api/v1.0/tweets/delete/?tweetId=${e.target.id}`;
        Axios.delete(deleteUrl)
            // eslint-disable-next-line
            .then((respons) => {
                getTweets();
            });
    }

    const handlePostTweet = (e) => {
        let tweetData = document.getElementById("textarea").value;
        if (tweetData.trim() !== "") {
            let tweetUrl = "http://localhost:8090/api/v1.0/tweets/posttweet";

            let inputdata = {
                "emailId": getUser(),
                "tweetDesc": tweetData
            };

            Axios.post(tweetUrl, inputdata)
                // eslint-disable-next-line
                .then((respons) => {
                    document.getElementById("textarea").value = '';
                    getTweets();
                });
        }
        document.getElementById("textarea").value = '';
    }

    const handleLike = (e) => {
        if (e.target.style.backgroundColor !== "brown") {
            e.target.style.backgroundColor = "brown";
        }
        else {
            e.target.style.backgroundColor = "";
        }
    }

    const enableReply = (e) => {
        let elem = document.getElementById(e.target.id + "-replyDiv").style.display;
        if (elem === "block") {
            document.getElementById(e.target.id + "-replyDiv").style.display = "none";
        }
        else {
            document.getElementById(e.target.id + "-replyDiv").style.display = "block";
        }

    }
    const handlesendReply = (e) => {
        let replyData = document.getElementById(e.target.id + "-textBox").value;
        if (replyData !== "") {
            let replyUrl = "http://localhost:8090/api/v1.0/tweets/reply";

            let inputdata = {
                "email": getUser(),
                "tweetId": e.target.id,
                "replyDesc": replyData
            }

            Axios.post(replyUrl, inputdata)
                .then((res) => {
                    getTweets();
                })
        }
        document.getElementById(e.target.id + "-replyDiv").style.display = "none";
        document.getElementById(e.target.id + "-textBox").value = "";

    }


    useEffect(() => {
        getTweets();
    }, []);

    return (
        <div>
            <div className="profileParent">
                <div >
                    <textarea className="textBox" rows="5" id="textarea" placeholder="Type Your Tweet"></textarea>
                    <input
                        type="button"
                        className="textBtn"
                        onClick={handlePostTweet}
                        value="POST"
                    />
                </div>
                <div>
                    {userData && userData.map((item, index) => (
                        (item.tweetDesc !== "") && (
                            <div key={index}>
                                <div
                                    className="usertweet-reply"
                                    >
                                    <div
                                        className="alltweet-wrapper">
                                        <img
                                            src={personLogo}
                                            className="personImgUser">
                                        </img>
                                        <label
                                            style={{ "position": "relative"}}>
                                            Posted by {item.tweetBy}
                                            <span style={{ "paddingLeft": "4%"}}>
                                                {timeFormating(new Date(item.date))} ago
                                    </span>
                                        </label>
                                        <span
                                            style={{ "fontSize": "20px", "color": "brown", "display": "table-row", "font-weight": "bold" }}>
                                            {item.tweetDesc}
                                        </span>
                                        <br />
                                        <label style={{ "display": "table-footer-group" }}>
                                            <img
                                                src={likeLogo}
                                                id={item.tweetId}
                                                onClick={handleLike}
                                                className="likeLogo">
                                            </img>
                                            <span
                                                className="replyText"
                                                id={item.tweetId}
                                                onClick={enableReply}
                                            >Reply
                                        </span>
                                        </label>
                                    </div>
                                    {/* <br /> */}
                                    {item.replyDTOList.length !== 0 &&
                                        item.replyDTOList.map((itm, index) => (

                                            <div
                                                className="replytweet-wrapper"
                                                key={index}
                                            >
                                                <img
                                                    src={personLogo}
                                                    className="personImgUser">
                                                </img>
                                                <label
                                                    style={{ "position": "relative",  "color": "antiquewhite" }}>
                                                    Commented by {itm.email}
                                                    <span style={{ "paddingLeft": "4%", "color": "cornsilk" }}>
                                                        {timeFormating(new Date(itm.date))} ago
                                    </span>
                                                </label>
                                                <span
                                                    style={{ "fontSize": "20px", "color": "aliceblue", "display": "table-row" }}>
                                                    {itm.replyDesc}
                                                </span>
                                            </div>
                                        ))}
                                    <div className="commentsdiv" id={item.tweetId + "-replyDiv"}>
                                        <input
                                            className="postcomment"
                                            type="button"
                                            value="post-comment"
                                            id={item.tweetId}
                                            onClick={handlesendReply}
                                        />
                                        <textarea
                                            className="replyTextarea"
                                            rows="5"
                                            id={item.tweetId + "-textBox"}
                                            placeholder="Type Your comments"
                                        ></textarea>
                                    </div>

                                </div>
                                <br />
                                <br />
                            </div>
                        )
                    ))}

                </div>
            </div>
        </div>

    )
}

export default Dashboard;
import React, { useState } from "react"
import { NavLink } from 'react-router-dom';
import "./styles/LoginStyle.css";

const Header = (props) => {
  const [showmenu, setshowmenu] = useState(true);

  const handleDropdownMenu = () => {
    setshowmenu((p) => !p);
    if (showmenu) {
      document.getElementById("myDropdown").style.display = "block";
    }
    else {
      document.getElementById("myDropdown").style.display = "none";
    }
  }



  return (
    <div>
      <div class="jumbotron">
        <div class="container text-center">
          <h1>Tweet App</h1>
        </div>
      </div>
      <div className="header">
        <div id="loginbtn" style={{ position: "absolute", left: "3%" }}> <NavLink exact activeClassName="active" to="/">Login</NavLink></div>
        <div id="registerbtn" style={{ position: "absolute", left: "10%" }} ><NavLink activeClassName="active" to="/register">Register</NavLink></div>
          {/* <h2 id="headtext" style={{ display: "inline", left: "41%", position: "relative" }}>Welcome To TweetAPP</h2> */}
          {/* <div id="logoutbtn" style={{ display: "none" }}><NavLink activeClassName="active" to="/logout" style={{ position: "absolute", right: "126px" }}>Logout</NavLink></div> */}
        <div id="dropDownMenu" className="dropdownMenu">
          <input type="button" onClick={handleDropdownMenu} className="dropdownMenu" value=" Menu ▼ "/>
          <div id="myDropdown" className="dropdown-content">
            <NavLink activeClassName="active" to="/dashboard" >Home</NavLink>
            <NavLink activeClassName="active" to="/allusers" >ShowAllUser</NavLink>
            <NavLink activeClassName="active" to="/resetPassword" >ResetPassword</NavLink>
            <NavLink activeClassName="active" to="/mytweets" >MyTweets</NavLink>
            <NavLink activeClassName="active" to="/logout" >Logout</NavLink>
          </div>
        </div>
      </div>
      <div>
        <h2 id="headtext" className="headtext">Welcome To Digital World</h2>
      </div>
    </div>
  )
}

export default Header;
package com.tweetapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.tweetapp.DBConnection;

public class ResetPasswordDao {

	public boolean oldPasswordCheck(String userName, String oldPassword) {
		
		boolean result = false;
		try {
			String query = "SELECT * from user_info WHERE us_email_id=? AND us_password=?";
			Connection connection = DBConnection.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, userName);
			preparedStatement.setString(2, oldPassword);
			ResultSet rs = preparedStatement.executeQuery();
			if (rs.next()) {
				result = true;
			}
			DBConnection.disconnect(connection);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;

	}

	public boolean resetPassword(String userName, String newPassword) {

		boolean returnState = false;
		try {
			String updateQuery = "UPDATE user_info SET us_password =? WHERE us_email_id =?";
			Connection connection = DBConnection.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(updateQuery);
			preparedStatement.setString(1, newPassword);
			preparedStatement.setString(2, userName);
			int count = preparedStatement.executeUpdate();
			returnState = count >= 1;
			DBConnection.disconnect(connection);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return returnState;
	}
}

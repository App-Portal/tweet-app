package com.tweetapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.tweetapp.DBConnection;

public class LoginDao {

	public boolean loginUser(String emailId, String password) {

		boolean returnState = false;
		try {
			String query = "SELECT * from user_info WHERE us_email_id=? and us_password=?";
			Connection connection = DBConnection.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, emailId);
			preparedStatement.setString(2, password);
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				returnState = true;
			} else {
				returnState = false;
			}
			DBConnection.disconnect(connection);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return returnState;
	}
}

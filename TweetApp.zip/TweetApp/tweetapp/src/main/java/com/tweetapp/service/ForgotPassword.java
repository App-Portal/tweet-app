package com.tweetapp.service;

import java.util.Scanner;

import com.tweetapp.dao.ForgotPasswordDao;

public class ForgotPassword {

	Scanner scanner = new Scanner(System.in);

	public void forgotPassword() {
		System.out.println("********* FORGOT PASSWORD FORM *********");
		System.out.print("Enter user name:");
		String userName = scanner.nextLine();
		System.out.print("Enter New password:");
		String newPassword = scanner.nextLine();
		ForgotPasswordDao forgotPasswordDao = new ForgotPasswordDao();
		if (forgotPasswordDao.forgotPasswordDao(userName, newPassword)) {
			System.out.println("Password Changed Successfully.Try to Login");
			LoginService loginService = new LoginService();
			loginService.getLogin();
		} else {
			System.out.println("Failed to change Password");
		}
	}
}
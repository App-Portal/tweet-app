package com.tweetapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashSet;

import com.tweetapp.DBConnection;
import com.tweetapp.model.Tweet;

public class ViewTweetsDao {

	public ArrayList<Tweet> getMyTweets(String userName) {

		ArrayList<Tweet> tweetArray = new ArrayList<Tweet>();
		try {
			String query = "SELECT * from tweet_details WHERE tweet_user=?";
			Connection connection = DBConnection.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, userName);
			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				Tweet tweet = new Tweet();
				tweet.setTweet(resultSet.getString(2));
				tweet.setUserName(resultSet.getString(1));
				tweetArray.add(tweet);
			}
			DBConnection.disconnect(connection);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return tweetArray;
	}

	public ArrayList<Tweet> getAllTweets() {
		ArrayList<Tweet> tweetArray = new ArrayList<Tweet>();
		try {
			String query = "SELECT * from tweet_details";
			Connection connection = DBConnection.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				Tweet tweet = new Tweet();
				tweet.setTweet(resultSet.getString(2));
				tweet.setUserName(resultSet.getString(1));
				tweetArray.add(tweet);
			}
			DBConnection.disconnect(connection);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return tweetArray;
	}

	public HashSet<String> getAllUsers() {
		HashSet<String> userSet = new HashSet<String>();
		try {
			String query = "SELECT * from user_info";
			Connection connection = DBConnection.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				userSet.add(resultSet.getString(4));
			}
			DBConnection.disconnect(connection);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return userSet;
	}
}

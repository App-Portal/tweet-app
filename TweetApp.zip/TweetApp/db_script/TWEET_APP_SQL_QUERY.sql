create database tweet_app;

use tweet_app;

create table user_info(
us_first_name varchar(60) not null, 
us_last_name varchar(60), 
us_gender varchar(12) not null,  
us_email_id varchar(50) not null unique, 
us_dob date,
us_password varchar(100) not null
);

create table tweet_details(
tweet_user varchar(60) not null,
tweet_message varchar(60) not null
);


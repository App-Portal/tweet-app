import React from 'react';
import { BrowserRouter } from 'react-router-dom';
 
import Login from './components/Login';
import Register from './components/Register';
import Header from './components/Header';
import Success from './components/Success';
import Dashboard from './components/Dashboard';
import Logedout from './components/Logout';
import ResetPassword from './components/ResetPassword';
import ShowAllUsers from './components/ShowAllUsers';
import PublicRoute from './components/Routes/PublicRoute';
import PrivateRoute from './components/Routes/PrivateRoute';
import MyTweets from './components/MyTweets';
 
function App() {
  return (
    <div className="App" style={{zoom:"80%"}}>
      <BrowserRouter>
        <div>
          <Header />
          <div className="content">
              <PublicRoute exact path="/" component={Login} />
              <PublicRoute path="/register" component={Register} />
              <PrivateRoute path="/success" component={Success} />   
              <PrivateRoute path="/dashboard" component={Dashboard} /> 
              <PrivateRoute path="/logout" component={Logedout} />     
              <PrivateRoute path="/resetPassword" component={ResetPassword} /> 
              <PrivateRoute path="/allusers" component={ShowAllUsers} />   
              <PrivateRoute path="/mytweets" component={MyTweets} /> 
          </div>
        </div>
      </BrowserRouter>
    </div>
  );
}
 
export default App;
import React, { useState, useEffect } from 'react';
import "./styles/LoginStyle.css";
import { setUserSession } from '../Utils/Common';
import Axios from "axios";

function Register(props) {

  document.title = "Register";
  let doc = document.getElementById("regform");
  const [selectclass, setselectclass] = useState({ fname: false, lname: false, pas: false, confpass: false, loginid: false, contactNum: false, email: false });
  const [errumsg, seterrumsg] = useState("");
  const [errunmsg, seterrunmsg] = useState("");
  const [erremmsg, seterremmsg] = useState("");
  const [errmesg,seterrmesg] = useState("")
  const [userDetails, setuserDetails] = useState();

  let elem = document.getElementById("dropDownMenu");
  if (elem !== null) {
    elem.style.display = "none";
  }

  const changeValuename = (e) => {

    if (e.target.value !== "" && e.target.value.match("^[a-zA-Z]+$") === null) {
      document.getElementById("err1").style.display = "block";
      seterrumsg("*Name should contain only alphabets");
    }
    else if (e.target.value.match("^[a-zA-Z]+$") !== null) {
      document.getElementById("err1").style.display = "none";
      seterrumsg("");
      setuserDetails({ ...userDetails, firstName: doc.elements[0].value });
    }
  }

  const changeValueuname = (e) => {
    if (e.target.value !== "" && e.target.value.match("^[a-zA-Z]+$") === null) {
      document.getElementById("erruname").style.display = "block";
      seterrunmsg("*User name should contain only alphabets");

    }
    else if (e.target.value === "" || e.target.value.match("^[a-zA-Z]+$") !== null) {
      document.getElementById("erruname").style.display = "none";
      seterrunmsg("");
      setuserDetails({ ...userDetails, lastName: doc.elements[1].value });
    }
  }



  const changeValueemail = (e) => {

    var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
    if (reg.test(e.target.value) === false && e.target.value !== "") {
      document.getElementById("erremail").style.display = "block";
      seterremmsg("*Enter valid email address");
    }
    else {
      document.getElementById("erremail").style.display = "none";
      seterremmsg("");
      setuserDetails({ ...userDetails, email: e.target.value });
    }
  }

  const handleSubmit = (e) => {
    if (errumsg !== "" || errunmsg !== "" || erremmsg !== "") {
      alert("Please Enter proper details");
      e.preventDefault();
    }
    else {
      let registerUrl = "http://localhost:8090/api/v1.0/tweets/register";

      let inputdata = {
        "email": userDetails.email,
        "firstName": userDetails.firstName,
        "lastName": userDetails.lastName,
        "password": userDetails.password,
        "id": userDetails.loginId,
        "gender": "male"
      }

      Axios.post(registerUrl, inputdata)
        // eslint-disable-next-line
        .then((respons) => {
          console.log(respons.data);
          if (respons.data.sucessMessage === "Registration Successful") {
            // setUserSession(userDetails);
            props.history.push('/');
          }
          else {
            seterrmesg(respons.data.errorMessage);
            setTimeout(() => {
              seterrmesg(null);
            }, 6000);
          }
        });
     

    }
  }

  const changeConfirmPass = (e) => {
    if (e.target.value != userDetails.password) {
      document.getElementById("confpass").style.display = "block";
    }
    else {
      document.getElementById("confpass").style.display = "none";

    }
  }

  return (

    <div>
    <form className="form-wrapper" id="regform" autoComplete="off">
      <h2 style={{ textAlign: "center", fontWeight: "bold" }}>REGISTER</h2>
      <div className={`field ${selectclass.fname ? "active" : ""}`}>
        <input
          id={1}
          type="text"
          name="Name"
          placeholder="Enter First Name"
          onChange={changeValuename}
          onFocus={() => setselectclass({ fname: true })}
          onBlur={() => setselectclass({ fname: false })}
          required
        />
        <label htmlFor={1}>
          {"FirstName"}
        </label>
      </div>
      <div><label style={{ display: "none", color: "darkred" }} id='err1'>{errumsg}</label></div> <br />
      <div className={`field ${selectclass.lname ? "active" : ""}`}>
        <input
          id={2}
          type="Username"
          placeholder="Enter Lastname"
          onChange={changeValueuname}
          onFocus={() => setselectclass({ lname: true })}
          onBlur={() => setselectclass({ lname: false })}
          required
        />
        <label htmlFor={2}>
          {"Lastname"}
        </label>
      </div>  <div><label style={{ display: "none", color: "darkred" }} id='erruname'>{errunmsg}</label></div><br />

      <div className={`field ${selectclass.email ? "active" : ""}`}>
        <input
          id={3}
          type="text"
          placeholder="Enter Email Address"
          onChange={changeValueemail}
          onFocus={() => setselectclass({ email: true })}
          onBlur={() => setselectclass({ email: false })}
          required
        />
        <label htmlFor={3}>
          {"Email Address"}
        </label>
      </div><div><label style={{ display: "none", color: "darkred" }} id="erremail">{erremmsg}</label></div><br />


      <div className={`field ${selectclass.pas ? "active" : ""}`}>
        <input
          id={4}
          type="password"
          placeholder="Enter Password"
          onChange={e => { setuserDetails({ ...userDetails, password: e.target.value }); }}
          onFocus={() => setselectclass({ pas: true })}
          onBlur={() => setselectclass({ pas: false })}
          required
        />
        <label htmlFor={4}>
          {"Password"}
        </label>
      </div> <br />
      <div className={`field ${selectclass.confpass ? "active" : ""}`}>
        <input
          id={5}
          type="password"
          placeholder="Confirm Password"
          onChange={changeConfirmPass}
          onFocus={() => setselectclass({ confpass: true })}
          onBlur={() => setselectclass({ confpass: false })}
          required
        />
        <label htmlFor={5}>
          {"Confirm password"}
        </label>
      </div><div><label style={{ display: "none", color: "darkred" }} id="confpass">Password is not matching </label></div> <br />

      <div className={`field ${selectclass.loginid ? "active" : ""}`}>
        <input
          id={6}
          type="text"
          placeholder="Enter LoginId"
          onChange={e => { setuserDetails({ ...userDetails, loginId: e.target.value }); }}
          onFocus={() => setselectclass({ loginid: true })}
          onBlur={() => setselectclass({ loginid: false })}
          required
        />
        <label htmlFor={6}>
          {"LoginID"}
        </label>
      </div><br />

      <div className={`field ${selectclass.contactNum ? "active" : ""}`}>
        <input
          id={7}
          type="text"
          placeholder="Enter Contact Number"
          onChange={e => { setuserDetails({ ...userDetails, contactNumber: e.target.value }); }}
          onFocus={() => setselectclass({ contactNum: true })}
          onBlur={() => setselectclass({ contactNum: false })}
          required
        />
        <label htmlFor={7}>
          {"Contact Number"}
        </label>
      </div><br />
      <div id="errdiv" ><span className="errmsg">{errmesg}</span></div>
      <br />

      <div className="field" style={{ background: "green", height: "90%", }}>
        <input
          type='button'
          value="SUBMIT"
          class="btn btn-success"
          onClick={handleSubmit}
          style={{ cursor: "pointer" }}
        />
      </div>     
    </form>
   
     </div>
  );
}

export default Register;